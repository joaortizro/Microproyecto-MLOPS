
def predict(data):
    # Dummy prediction logic
    return {
        "predicted_score": 2,
        "negative_probability": 0.81,
        "sentiment": "negative",
        "reasons": [
            {"factor": "delivery_delay", "value": 4, "impact": "high"},
            {"factor": "freight_cost", "value": 24.5, "impact": "medium"},
            {"factor": "review_text", "value": "damaged packaging", "impact": "medium"}
        ]
    }
